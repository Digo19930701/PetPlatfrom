package com.ispan.eeit;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class EmployeeCrudSdjpaApplication {

	public static void main(String[] args) {
		SpringApplication.run(EmployeeCrudSdjpaApplication.class, args);
	}

}
