<template>
  <div class="header">
    <div class="trademark">(icon)&copy;4A2B</div>
    <el-button text> 關於4A2B </el-button>
    <el-button text> 聯絡我們 </el-button>
    <el-button text> 隱私權政策 </el-button>
  </div>
</template>

<style scoped>
.header {
  background-color: #f8d479;
  width: auto;
  height: 60px;
  padding: 15px 0px 10px 20px;
  display: inline-flex;
}

.trademark {
  border-radius: 10px;
  height: 30px;
  width: 150px;
  background-color: #fff3bf;
  padding: 3px 30px;
}
</style>
