/*
$(document).ready(function(){
	$(".menu").hover(function(){
		$(this).css("border-color", "#F00")
		       .css("background-color", "#FF5a02")	
		       .css("color", "#0FF");
	},
	function(){
		$(this).css("border-color", "#FFF")
		       .css("background-color", "#EBFFEB")
		       .css("color", "#0FF");
	});
});
*/