package _03_listBooks.service.impl;

import java.io.Serializable;
import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import _03_listBooks.dao.CompanyDao;
import _03_listBooks.model.CompanyBean;
import _03_listBooks.service.CompanyService;
// 本類別負責讀取資料庫內eBookCompany表格內的紀錄
//
@Service
public class CompanyServiceImpl implements Serializable, CompanyService {

	private static final long serialVersionUID = 1L;

	private static Logger log = LoggerFactory.getLogger(CompanyServiceImpl.class);

	CompanyDao companyDao;
	@Autowired
	public CompanyServiceImpl(CompanyDao companyDao) {
		this.companyDao = companyDao;
	}

	@Transactional
	@Override
	public List<CompanyBean> findAll() {
		List<CompanyBean> companyBeans = null;
//		Session session = factory.getCurrentSession();
//		Transaction tx = null;
//		try {
//			tx = session.beginTransaction();
			companyBeans = companyDao.findAll();
//			tx.commit();
//		} catch (Exception ex) {
//			if (tx != null)
//				tx.rollback();
//			ex.printStackTrace();
//			throw new RuntimeException(ex);
//		}
		log.info("新增與更新書籍之前置作業之Service#findAll() companyBeans=" + companyBeans);
		return companyBeans;
	}
	@Transactional
	@Override
	public CompanyBean findById(Integer id) {
		CompanyBean companyBean = null;
//		Session session = factory.getCurrentSession();
//		Transaction tx = null;
//		try {
//			tx = session.beginTransaction();
			companyBean = companyDao.findById(id);
//			tx.commit();
//		} catch (Exception ex) {
//			if (tx != null)
//				tx.rollback();
//			ex.printStackTrace();
//			throw new RuntimeException(ex);
//		}
		log.info("Service#findById(), companyBean=" + companyBean);
		return companyBean;
	}
	@Transactional
	@Override
	public String getSelectTag(String tagName, int selected) {
		String ans = "";
		List<CompanyBean> cb = findAll();
		ans += "<SELECT name='" + tagName + "'>";
		for (CompanyBean bean : cb) {
			int id = bean.getId();
			String name = bean.getName().substring(0, 4);
			if (id == selected) {
				ans += "<option value='" + id + "' selected>" + name + "</option>";
			} else {
				ans += "<option value='" + id + "'>" + name + "</option>";
			}
		}
		ans += "</SELECT>";
		log.info("新增與更新書籍之前置作業之Service#getSelectTag(), getSelectTag=" + ans);
		return ans;
	}

}