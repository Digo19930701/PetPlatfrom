package _00_init.service;
 
public interface BaseService {
	public void initData();
}
