package _00_init.dao;

public interface BaseDao {
	void rebuildTableAndIndex();
	void loadInitData();
}
