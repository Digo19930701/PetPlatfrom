<script setup>
import HomeHeader from '../components/HomeHeader.vue'
import Home from '../components/Home.vue'
</script>

<template>
  <HomeHeader />
  <Home />
</template>
