<script setup>
import HomeHeader from '../components/HomeHeader.vue'
import Good from '../components/Good.vue'
</script>

<template>
  <HomeHeader />
  <Good />
</template>
