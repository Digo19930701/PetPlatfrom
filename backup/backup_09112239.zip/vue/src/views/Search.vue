<script setup>
import HomeHeader from '../components/HomeHeader.vue'
import SearchMenu from '../components/SearchMenu.vue'
</script>

<template>
  <HomeHeader />
  <SearchMenu />
</template>
